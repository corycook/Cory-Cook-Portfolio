                <center><p>
                    In case of a hazardous material spill or exposure to infectious material, remain calm, and proceed as follows:
                </p>
                <div data-role="fieldcontain">
                    <fieldset data-role="controlgroup" data-type="vertical">
                        <legend>
                            Chemical and Solvent Spills: If spill involves per-sonal injury:
                        </legend>
                        <input name="checkbox8" id="checkbox8" type="checkbox" />
                        <label for="checkbox8">
                            Remove Clothing
                        </label>
                        <input name="checkbox12" id="checkbox12" type="checkbox" />
                        <label for="checkbox12">
                            Flush with warm tap water for 15 minutes
                        </label>
                        <input name="checkbox13" id="checkbox13" type="checkbox" />
                        <label for="checkbox13">
                            Call 911 from a campus phone or 537-7777 from a cell phone.
                        </label>
                    </fieldset>
                </div>
                <div data-role="fieldcontain">
                    <fieldset data-role="controlgroup" data-type="vertical">
                        <legend>
                            If immediate hazard exists or medical assistance is required:
                        </legend>
                        <input name="checkbox9" id="checkbox9" type="checkbox" />
                        <label for="checkbox9">
                            Call 911 from a campus phone or 537-7777 from a cell phone.
                        </label>
                        <input name="checkbox14" id="checkbox14" type="checkbox" />
                        <label for="checkbox14">
                            Immediately evacuate and limit access to the affected area.
                        </label>
                        <input name="checkbox15" id="checkbox15" type="checkbox" />
                        <label for="checkbox15">
                            All evacuations should be upwind from the release location.
                        </label>
                    </fieldset>
                </div>
                <div data-role="fieldcontain">
                    <fieldset data-role="controlgroup" data-type="vertical">
                        <legend>
                            For small spills/those not involving immediate danger to lives or property:
                        </legend>
                        <input name="checkbox10" id="checkbox10" type="checkbox" />
                        <label for="checkbox10">
                            Confine the spill.
                        </label>
                        <input name="checkbox16" id="checkbox16" type="checkbox" />
                        <label for="checkbox16">
                            Evacuate and secure the immediate area; limit access to authorized personnel.
                        </label>
                    </fieldset>
                </div>
                <div data-role="fieldcontain">
                    <fieldset data-role="controlgroup" data-type="vertical">
                        <legend>
                            Contact Environmental Health &amp; Safety (EHS) (909) 537-5179
                        </legend>
                        <input name="checkbox11" id="checkbox11" type="checkbox" />
                        <label for="checkbox11">
                            Identify yourself and report the information.
                        </label>
                        <input name="checkbox17" id="checkbox17" type="checkbox" />
                        <label for="checkbox17">
                            Be as specific as possible about the type, amount of the spill/material released.
                        </label>
                        <input name="checkbox18" id="checkbox18" type="checkbox" />
                        <label for="checkbox18">
                            Provide the location of the spill.
                        </label>
                    </fieldset>
                </div>
                <p>
                    Unless immediate medical attention is needed, all persons who have been potentially exposed should report to emergency personnel at the Incident Command Post site and notify the inci-dent Commander that they have been exposed.
                </p>
            