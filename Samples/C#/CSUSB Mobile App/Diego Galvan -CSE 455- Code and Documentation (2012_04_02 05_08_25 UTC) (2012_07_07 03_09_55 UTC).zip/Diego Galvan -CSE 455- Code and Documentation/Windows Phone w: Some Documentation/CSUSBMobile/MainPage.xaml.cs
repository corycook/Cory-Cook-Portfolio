using System;
using System.Windows;
using Microsoft.Phone.Controls;

namespace CSUSBMobile {
    public partial class MainPage : PhoneApplicationPage {

        // Constructor
        public MainPage() {
            InitializeComponent();
            webBrowser1.IsScriptEnabled = true;
            string site = "http://mobile.dev.ias.csusb.edu/WebView/index.php";
            webBrowser1.Navigate(new Uri(site, UriKind.Absolute));
        }
    }
}
